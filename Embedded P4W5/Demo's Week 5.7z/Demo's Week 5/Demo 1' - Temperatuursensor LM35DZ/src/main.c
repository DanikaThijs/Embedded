#include <avr/io.h>
#include <stdlib.h>
#include <util/delay.h>
#include <display.h>

#define Vref 1000          // Vref is 1V, maximale output

void initADC() {       // zie demo potentiometer!!
  ADMUX |= _BV(REFS0); // kies interne 5V (VCC) als referentiespanning
  ADCSRA |= _BV(ADPS2) | _BV(ADPS1) | _BV(ADPS0); // stel prescaling factor in op 16 Mhz / 128 = 125 Khz
  ADCSRA |= _BV(ADEN); // enable AD Conversie
}

uint16_t readADC(uint8_t channel) {
  ADMUX = (ADMUX & 0xf0) | channel;      // plaats het gewenste channel in de laagste 4 bits van ADMUX-register
  ADCSRA |= _BV(ADSC);                   // trigger conversie
  loop_until_bit_is_clear(ADCSRA, ADSC); // wacht tot ADSC nul (cleared) is, dan is conversie gedaan
  return ADC;
}

double to_voltage(int rawADC) {
  return rawADC * (Vref / 1023.0); // 0 = 0V en 1023 = 1V
}

double to_temperture(int rawADC) {
  return to_voltage(rawADC) / 10.0;
}

int main() {
  initDisplay();
  initADC();
  uint16_t rawADC;
  double temp;
  double voltage;
  while (1) {
    rawADC = readADC(PC5);              // lees ADC waarde op A5 (PC5).
    voltage = to_voltage(rawADC);       // zet ADC om naar spanning
    temp = to_temperture(rawADC);       // zet ADC om naar temperatuur
    writeNumberAndWait(temp,1000);
  }
 return 0;
}