#define __DELAY_BACKWARD_COMPATIBLE__  // to allow variables as parameter for the _delay-functions (must be placed before the include of delay.h)
#include <util/delay.h> 
#include <avr/io.h> 
#include <pitches.h>


void enableBuzzer() {
   DDRD |= (1 << (PD3)); // The buzzer is at PORTD3
}

void soundBuzzer(){
    PORTD &= ~(1 << (PD3));
}

void noSoundBuzzer(){
    PORTD |= (1 << (PD3));
}


void wait(long period) { 
   _delay_ms (period / 1000);    // First delay for the number of whole milliseconds  
   _delay_us (period % 1000);    // Then delay for the remainder of microseconds  
} 

void playOneNote(int frequencyInHz, uint8_t noteType, uint8_t bpm) { 
   float beatDuration = (60.0 / bpm) * 1000000L;               // Time between two beats in microseconds (equal to length of a quarter note)
   float noteGap = beatDuration *  0.1;                        // Time of the gap between two notes in microseconds
   long halfPeriod = (1000000L/frequencyInHz) / 2;             // in microseconds
   long noteDuration = beatDuration * (4.0 / noteType);        // in microseconds
   long elapsed = 0; 
    while(halfPeriod > 0 && elapsed < (noteDuration - noteGap)) { 
      soundBuzzer(); 
      wait(halfPeriod);         
      noSoundBuzzer(); 
      wait (halfPeriod); 
      elapsed += halfPeriod * 2; 
    } 
    wait((noteDuration - elapsed)); 
} 


int main () {          // play melody only once
  uint8_t bpm = 96;   // beats per minute
/* Mukkathe Penne
 int melody[] = {NOTE_D4, NOTE_G4, NOTE_FS4, NOTE_A4, NOTE_G4, NOTE_C5, NOTE_AS4, NOTE_A4,                   
                 NOTE_FS4, NOTE_G4, NOTE_A4, NOTE_FS4, NOTE_DS4, NOTE_D4, NOTE_C4, NOTE_D4,
                 0, NOTE_D4, NOTE_G4, NOTE_FS4, NOTE_A4,  NOTE_G4, NOTE_C5, NOTE_D5, 
                 NOTE_C5, NOTE_AS4, NOTE_C5, NOTE_AS4, NOTE_A4, NOTE_FS4, NOTE_G4, NOTE_A4, 
                 NOTE_FS4, NOTE_DS4, NOTE_D4, NOTE_C4, NOTE_D4, 0, NOTE_D4, NOTE_FS4, NOTE_G4, 
                 NOTE_A4, NOTE_DS5, NOTE_D5, NOTE_C5, NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_C4, 
                 NOTE_D4, NOTE_DS4, NOTE_FS4, NOTE_D5, NOTE_C5, NOTE_AS4, NOTE_A4, NOTE_C5, 
                 NOTE_AS4, NOTE_D4, NOTE_FS4, NOTE_G4, NOTE_A4, NOTE_DS5, NOTE_D5, NOTE_C5, 
                 NOTE_D5, NOTE_C5, NOTE_AS4, NOTE_C5, NOTE_AS4, NOTE_A4, NOTE_C5, NOTE_G4, 
                 NOTE_A4, 0, NOTE_AS4, NOTE_A4, 0, NOTE_G4, NOTE_G4, NOTE_A4, 
                 NOTE_G4, NOTE_FS4, 0, NOTE_C4, NOTE_D4, NOTE_G4, NOTE_FS4, NOTE_DS4, 
                 NOTE_C4, NOTE_D4, 0, NOTE_C4, NOTE_D4, NOTE_G4, NOTE_FS4, NOTE_DS4, 
                 NOTE_C4, NOTE_D4};
uint8_t noteType[] = {8,4,8,4,4,4,4,12,4,4,4,4,4,4,4,16,4,8,4,8,4,4,2,1,
                          1,2,1,1,12,4,4,4,4,4,4,4,16,4,4,4, 4,4,4,4,4,4,4,12,
                          4,4,4,4,4,4,4,4,4,12,4,4,4,4,4,4,2,1,1,2,1,1,4,8,
                          4,2,6,4,2,6,4,2,1,1,16,4,4,8,4,4,4,4,16,4,4,8,4,4,4,4};
*/

/* Mario main theme
int melody[] = {NOTE_E7, NOTE_E7, 0, NOTE_E7, 0, NOTE_C7, NOTE_E7, 0,
                NOTE_G7, 0, 0,  0, NOTE_G6, 0, 0, 0,
                NOTE_C7, 0, 0, NOTE_G6, 0, 0, NOTE_E6, 0,
                0, NOTE_A6, 0, NOTE_B6, 0, NOTE_AS6, NOTE_A6, 0,
                NOTE_G6, NOTE_E7, NOTE_G7, NOTE_A7, 0, NOTE_F7, NOTE_G7,
                0, NOTE_E7, 0, NOTE_C7, NOTE_D7, NOTE_B6, 0, 0,
                NOTE_C7, 0, 0, NOTE_G6, 0, 0, NOTE_E6, 0,
                0, NOTE_A6, 0, NOTE_B6, 0, NOTE_AS6, NOTE_A6, 0,
                NOTE_G6, NOTE_E7, NOTE_G7, NOTE_A7, 0, NOTE_F7, NOTE_G7,
                0, NOTE_E7, 0, NOTE_C7, NOTE_D7, NOTE_B6, 0, 0};
uint8_t noteType[] = {12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
                           12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
                           9, 9, 9, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
                           12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 9, 9, 9, 12, 12, 12, 12,
                           12, 12, 12, 12, 12, 12, 12, 12};
bpm = 200;
*/

/* Underworld melody
int melody[] = {NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4, NOTE_AS3, NOTE_AS4, 0, 0,
                NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4, NOTE_AS3, NOTE_AS4, 0, 0,
                NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4, NOTE_DS3, NOTE_DS4, 0, 0,
                NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4, NOTE_DS3, NOTE_DS4, 0, 0, 
                NOTE_DS4, NOTE_CS4, NOTE_D4, NOTE_CS4, NOTE_DS4,NOTE_DS4, NOTE_GS3,
                NOTE_G3, NOTE_CS4, NOTE_C4, NOTE_FS4, NOTE_F4, NOTE_E3, NOTE_AS4, 
                NOTE_A4, NOTE_GS4, NOTE_DS4, NOTE_B3, NOTE_AS3, NOTE_A3, NOTE_GS3, 0, 0, 0 };
uint8_t noteType[] = {12, 12, 12, 12, 12, 12, 6, 3, 12, 12, 12, 12, 12, 12, 6, 3,
                           12, 12, 12, 12, 12, 12, 6, 3, 12, 12, 12, 12, 12, 12, 6, 6, 
                           18, 18, 18, 6, 6, 6, 6, 6, 6, 18, 18, 18, 18, 18, 18, 10, 10, 
                           10, 10, 10, 10, 3, 3, 3};
*/

/* Tetris 
 int melody[] = {NOTE_E5, NOTE_B4, NOTE_C5, NOTE_D5, NOTE_C5, NOTE_B4, NOTE_A4, NOTE_A4, 
                 NOTE_C5, NOTE_E5, NOTE_D5, NOTE_C5, NOTE_B4, NOTE_B4, NOTE_C5, NOTE_D5, 
                 NOTE_E5, NOTE_C5, NOTE_A4, NOTE_A4, 0, NOTE_D5, NOTE_F5, NOTE_A5, 
                 NOTE_G5, NOTE_F5, NOTE_E5, NOTE_C5, NOTE_E5, NOTE_D5, NOTE_C5, NOTE_B4, 
                 NOTE_B4, NOTE_C5, NOTE_D5, NOTE_E5, NOTE_C5, NOTE_A4, NOTE_A4, 0,
                 NOTE_E4, NOTE_C4, NOTE_D4, NOTE_B3, NOTE_C4, NOTE_A3, NOTE_GS3, NOTE_B3,
                 NOTE_E4, NOTE_C4, NOTE_D4, NOTE_B3, NOTE_C4, NOTE_E4, NOTE_A4, NOTE_A4, 
                 NOTE_GS4, 0};
 int noteType[] = {4, 2, 2, 4, 2, 2, 4, 2, 2, 4, 2 ,2, 4, 2, 2, 4, 4, 4, 4, 4,
                        4, 6, 2, 4, 2, 2, 6, 2, 4, 2, 2, 4, 2, 2, 4, 4, 4, 4, 4, 4,
                        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 4, 4, 4, 4, 12, 4}; 
 bpm = 144;
*/

/* Axel F - Beverly Hills Cop
 int melody[] = {NOTE_D4, 0, NOTE_F4, NOTE_D4, 0, NOTE_D4, NOTE_G4, NOTE_D4, NOTE_C4,
                 NOTE_D4, 0, NOTE_A4, NOTE_D4, 0, NOTE_D4, NOTE_AS4, NOTE_A4, NOTE_F4,
                 NOTE_D4, NOTE_A4, NOTE_D5, NOTE_D4, NOTE_C4, 0, NOTE_C4, NOTE_A3, 
                 NOTE_E4, NOTE_D4, 0}; 
 int noteType[] = {8, 8, 6, 16, 16, 16, 8, 8, 8, 8, 8, 6, 16, 16, 16, 8, 8, 8, 
                        8, 8, 8, 16, 16, 16, 16, 8, 8, 2, 2}; 
*/

/* The Lion Sleeps Tonight
 int melody[] = {NOTE_F4, NOTE_G4, NOTE_A4, NOTE_G4, NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_G4, 
                 NOTE_F4, NOTE_G4, NOTE_A4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_C4, 
                 NOTE_F4, NOTE_G4, NOTE_A4, NOTE_G4, NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_G4, 
                 NOTE_F4, NOTE_G4, NOTE_A4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_C4, 0}; 
 int noteType[] = {4, 4, 8, 4, 8, 4, 4, 8, 4, 8, 4, 8, 4, 8, 4, 1, 4, 4, 8, 4, 8, 4, 
                        4, 8, 4, 8, 4, 8, 4, 8, 4, 2, 8}; 
bpm = 122;
*/

/*Theme song of Pirates of caribbean
int melody[] = {NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, 
                NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_A3, NOTE_C4, NOTE_D4, NOTE_D4, 
                NOTE_D4, NOTE_E4, NOTE_F4, NOTE_F4, NOTE_F4, NOTE_G4, NOTE_E4, NOTE_E4, NOTE_D4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_A3, NOTE_C4, 
                NOTE_B3, NOTE_D4, NOTE_B3, NOTE_E4, NOTE_F4, NOTE_F4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_C4, NOTE_D4, 0, 0, 
                NOTE_A3, NOTE_C4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_F4, NOTE_G4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4,
                NOTE_A4, NOTE_D4, 0, NOTE_D4, NOTE_E3, NOTE_F4, NOTE_F4, NOTE_G4, NOTE_A4, NOTE_D4, 0, NOTE_D4, NOTE_F4, NOTE_E4, NOTE_E4, 
                NOTE_F4, NOTE_D4};
uint8_t noteType[] = {4,8,4,8,4,8,8,8,8,4,8,4,8,4,8,8,8,8,4,8,4,8,4,8,8,8,8,4,4,8,8,4,4,8,8,4,4,8,8,8,4,8,8,8,4,4,8,8,4,4,8,8,4,4,8,4,
                       4,8,8,8,8,4,4,8,8,4,4,8,8,4,4,8,8,8,4,8,8,8,4,4,4,8,4,8,8,8,4,4,8,8};
*/

/* Game of Thrones
int melody[] = {NOTE_G4,NOTE_C4,NOTE_DS4,NOTE_F4, NOTE_G4,NOTE_C4,NOTE_DS4,NOTE_F4, NOTE_G4,NOTE_C4,NOTE_DS4,NOTE_F4, NOTE_G4,NOTE_C4,NOTE_DS4,NOTE_F4,
                NOTE_G4,NOTE_C4,NOTE_E4,NOTE_F4, NOTE_G4,NOTE_C4,NOTE_E4,NOTE_F4, NOTE_G4,NOTE_C4,NOTE_E4,NOTE_F4, NOTE_G4,NOTE_C4,NOTE_E4,NOTE_F4, 
                NOTE_G4, NOTE_C4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_C4, NOTE_DS4, NOTE_F4, 
                NOTE_D4,NOTE_G3,NOTE_AS3,NOTE_C4, NOTE_D4,NOTE_G3,NOTE_AS3,NOTE_C4, NOTE_D4,NOTE_G3,NOTE_AS3,NOTE_C4, 
                NOTE_D4, NOTE_F4, NOTE_AS3, NOTE_DS4, NOTE_D4, NOTE_F4, NOTE_AS3, NOTE_DS4, NOTE_D4, NOTE_C4,
                NOTE_GS3,NOTE_AS3,NOTE_C4,NOTE_F3, NOTE_GS3,NOTE_AS3,NOTE_C4,NOTE_F3, NOTE_GS3,NOTE_AS3,NOTE_C4,NOTE_F3 };
uint8_t noteType[] = {4,4,8,8, 4,4,8,8, 4,4,8,8, 4,4,8,8, 4,4,8,8, 4,4,8,8, 4,4,8,8, 4,4,8,8, 2,2,8,8,2,2,8,8,
                          4,4,8,8, 4,4,8,8, 4,4,8,8, 2,2,2,8,8,2,2,8,8,4, 8,8,4,4, 8,8,4,4, 8,8,4,4};
bpm = 85;
*/

/* Hedwig's theme fromn the Harry Potter Movies
int melody[] = {0, NOTE_D4, NOTE_G4, NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_D5, NOTE_C5, NOTE_A4, 
                NOTE_G4, NOTE_AS4, NOTE_A4,NOTE_F4, NOTE_GS4, NOTE_D4, NOTE_D4, NOTE_G4,
                NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_D5, NOTE_F5, NOTE_E5, NOTE_DS5, NOTE_B4, 
                NOTE_DS5, NOTE_D5, NOTE_CS5, NOTE_CS4, NOTE_B4, NOTE_G4, NOTE_AS4, NOTE_D5, 
                NOTE_AS4, NOTE_D5, NOTE_AS4, NOTE_DS5, NOTE_D5, NOTE_CS5, NOTE_A4, NOTE_AS4, 
                NOTE_D5, NOTE_CS5, NOTE_CS4, NOTE_D4, NOTE_D5, 0, NOTE_AS4, NOTE_D5, 
                NOTE_AS4, NOTE_D5, NOTE_AS4, NOTE_F5, NOTE_E5, NOTE_DS5, NOTE_B4, NOTE_DS5, 
                NOTE_D5, NOTE_CS5, NOTE_CS4, NOTE_AS4, NOTE_G4};
uint8_t noteType[] = {2, 4, 4, 8, 4,  2, 4, 2, 2, 4, 8, 4, 2, 4,  1, 4, 4, 8, 4, 2, 
                           4, 2, 4, 2, 4, 4, 8, 4, 2, 4, 1, 4, 2, 4, 2, 4, 2, 4, 2, 4, 4, 
                           8, 4, 2, 4, 1, 4, 4, 2, 4, 2, 4, 2, 4, 2, 4, 4, 8, 4, 2, 4, 1 };
bpm = 144;
*/

/* Pink Panther theme 
int melody[]  = {NOTE_DS4, NOTE_E4, 0, NOTE_FS4, NOTE_G4, 0, 
                 NOTE_DS4, NOTE_E4, NOTE_FS4, NOTE_G4, NOTE_C5, NOTE_B4, NOTE_E4, 
                 NOTE_G4, NOTE_B4, NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_D4,
                 NOTE_E4, 0, 0, NOTE_DS4, NOTE_E4, 0, NOTE_FS4, NOTE_G4, 0,
                 NOTE_DS4, NOTE_E4, NOTE_FS4, NOTE_G4, NOTE_C5, NOTE_B4, NOTE_G4, NOTE_B4,
                 NOTE_E5, NOTE_DS5, NOTE_D5, 0, 0, NOTE_DS4, NOTE_E4, 0, NOTE_FS4,
                 NOTE_G4, 0, NOTE_DS4, NOTE_E4, NOTE_FS4, NOTE_G4, NOTE_C5, NOTE_B4, NOTE_E4,
                 NOTE_G4, NOTE_B4, NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_D4, NOTE_E4,
                 0, 0, NOTE_E5, NOTE_D5, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_AS4,
                 NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_AS4, NOTE_A4, NOTE_G4,
                 NOTE_E4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_E4 };
uint8_t noteType[] = {8, 4, 8, 8, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 2, 16, 16,
                           16, 16, 2, 4, 8, 4, 4, 8, 8, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
                           1, 2, 4, 8, 8, 4, 8, 8, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 2, 
                           16, 16, 16, 16, 4, 4, 4, 8, 8, 8, 8, 8, 8, 16, 8, 16, 8, 16, 8,
                           16, 8, 16, 16, 16, 16, 16, 2};
bpm = 120;
*/

/* Pulo da gaita - Auto da Compadecida 
int melody[] = {NOTE_C5, NOTE_G4, NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_C4, NOTE_C4, NOTE_G4, 
                NOTE_G4, NOTE_G4, NOTE_C5, NOTE_G4, NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_C5, 
                NOTE_G4, NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_C4, NOTE_C4, NOTE_G4, NOTE_G4, 
                NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4, NOTE_C4, NOTE_C4, NOTE_C5, NOTE_G4, 
                NOTE_AS4, NOTE_A4, NOTE_G4, NOTE_C4, NOTE_C4, NOTE_G4, NOTE_G4, NOTE_G4,
                NOTE_C5, NOTE_G4, NOTE_AS4, NOTE_A4, NOTE_G4}; 
uint8_t noteType[] =  {4, 8, 4, 8,16, 8, 16, 16, 8, 16, 4, 8, 4, 8, 2, 4, 8, 4, 8, 
                            16, 8, 16, 16, 8, 16, 8, 8, 8, 8, 2, 4, 8, 4, 8,16, 8, 16, 
                            16, 8, 16,4, 8, 4, 8,2}; 
bpm = 108;
*/

/* Simpsons
int melody[]  = {NOTE_C4, NOTE_E4, NOTE_FS4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_C4, NOTE_G3, 
                 NOTE_FS3, NOTE_FS3, NOTE_FS3, NOTE_G3};
uint8_t noteType[] = {2, 4, 1, 8, 2, 4, 1, 1, 8, 1 ,1, 4};
bpm = 100;
*/

/* Star Trek Intro 
int melody[]  = {NOTE_D4,NOTE_G4, NOTE_C5,NOTE_B4, NOTE_G4, NOTE_E4, NOTE_A4, NOTE_D5};
uint8_t noteType[] = {8, 16, 4, 8, 16, 16, 16, 2};
bpm = 80;
*/

//* Star Wars - the Imperial March - Darth Vader Theme
int melody[] = {NOTE_A4, NOTE_A4, NOTE_A4, NOTE_F4, NOTE_C5, NOTE_A4, NOTE_F4, NOTE_C5, NOTE_A4, 0,
                NOTE_E5, NOTE_E5, NOTE_E5, NOTE_F5, NOTE_C5, NOTE_GS4, NOTE_F4, NOTE_C5, NOTE_A4};
uint8_t noteType[] = {4,4,4,6,16,4,6,16,4,4,4,4,4,6,16,4,6,16,4};
bpm = 108;
//*/

/* Star Wars - Cantina Band
int melody[] = {NOTE_B4, NOTE_E5, NOTE_B4, NOTE_E5, NOTE_B4, NOTE_E5, NOTE_B4, 0,
                NOTE_AS4, NOTE_B4, NOTE_B4, NOTE_AS4,NOTE_B4,NOTE_A4, 0, NOTE_GS4,
                NOTE_A4, NOTE_G4, NOTE_G4, NOTE_E4, NOTE_B4, NOTE_E5, NOTE_B4, NOTE_E5,
                NOTE_B4, NOTE_E5, NOTE_B4, 0, NOTE_AS4, NOTE_B4, NOTE_A4, NOTE_A4,
                NOTE_GS4, NOTE_A4, NOTE_D5, NOTE_C5, NOTE_B4, NOTE_A4, NOTE_B4,NOTE_E5, 
                NOTE_B4, NOTE_E5, NOTE_B4, NOTE_E5, NOTE_B4, 0,  NOTE_AS4, NOTE_B4, 
                NOTE_D5,NOTE_D5, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_E4, NOTE_G4, 
                NOTE_B4, NOTE_D5, NOTE_F5, NOTE_E5,NOTE_AS4, NOTE_AS4, NOTE_B4, NOTE_G4};
uint8_t noteType[] = {4, 4, 4, 4, 8, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 4, 2, 
                           4, 4, 4, 4, 8, 4, 8, 8, 8, 8, 4, 4, 8, -4, 8, 4, 4, 4, 4, 4,
                           4, 4, 8, 4, 8, 8, 8, 8, 4, 4, 8, 4, 4, 2, 2, 2, 2, 2, 4, 4, 
                           8, 8, 4, 4};
bpm = 140;
*/

/* kinderdeuntje 
int melody[]  = {NOTE_E5, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_G5, 
                 NOTE_C5, NOTE_D5, NOTE_E5, NOTE_F5, NOTE_F5, NOTE_F5, NOTE_F5, NOTE_F5, 
                 NOTE_E5, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_D5, NOTE_D5, NOTE_E5,
                 NOTE_D5, NOTE_G5};
uint8_t noteType[] = {8, 8, 4, 8, 8, 4, 8, 8, 8, 8, 2, 8, 8, 8, 8, 8, 8, 8, 16, 16,
                           8, 8, 8, 8, 4, 4};

*/

/* Jingle Bells 
int melody[]  = {NOTE_E4,NOTE_E4,NOTE_E4,NOTE_E4,NOTE_E4,NOTE_E4,NOTE_E4,NOTE_G4,NOTE_C4,NOTE_D4,NOTE_E4,0,NOTE_F4,NOTE_F4,NOTE_F4,NOTE_F4,
                 NOTE_F4,NOTE_E4,NOTE_E4,NOTE_E4,NOTE_E4,NOTE_D4,NOTE_D4,NOTE_E4,NOTE_D4,NOTE_G4};
uint8_t noteType[] = {8, 8, 4, 8, 8, 4, 8, 8, 8, 8, 2, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 4, 4};
*/

/* We wish you a merry Christmas
int melody[] = {NOTE_B3, NOTE_F4, NOTE_F4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_G4, NOTE_F4,
                NOTE_E4, NOTE_E4, NOTE_E4, NOTE_A4, NOTE_A4, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_F4, NOTE_D4, NOTE_B3, NOTE_B3, NOTE_D4, NOTE_G4,
                NOTE_E4, NOTE_F4}; 
uint8_t noteType[] = {4, 4, 8, 8, 8, 8, 4, 4, 4, 4, 8, 8, 8, 8, 4, 4, 4, 4, 8, 8, 8, 8, 4, 4, 8, 8, 4, 4, 4, 2};
*/

/* Santa Claus is coming to town
int melody[] = {NOTE_G4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_B4, NOTE_C5, NOTE_C5, NOTE_C5, NOTE_E4, NOTE_F4, NOTE_G4, 
                NOTE_G4, NOTE_G4, NOTE_A4, NOTE_G4, NOTE_F4, NOTE_F4, NOTE_E4, NOTE_G4, NOTE_C4, NOTE_E4,  NOTE_D4, NOTE_F4, NOTE_B3, NOTE_C4};
uint8_t noteType[] = {8, 8, 8, 4, 4, 4, 8, 8, 4, 4, 4, 8, 8, 4, 4, 4, 8, 8, 4, 2, 4, 4, 4, 4, 4, 2, 4, 1 };
*/

/* Happy Birthday
int melody[] = {NOTE_C4, NOTE_C4, NOTE_D4, NOTE_C4, NOTE_F4, 
                NOTE_E4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_C4, NOTE_G4,
                NOTE_F4, NOTE_C4, NOTE_C4, NOTE_C5, NOTE_A4, NOTE_F4, 
                NOTE_E4, NOTE_D4, NOTE_AS4, NOTE_AS4, NOTE_A4, NOTE_F4, NOTE_G4, NOTE_F4};
uint8_t noteType[] = {4, 8, 4, 4, 4, 2, 4, 8, 4, 4, 4, 2, 4, 8, 4, 4, 4, 
                           4, 4, 4, 8, 4, 4, 4, 2};
*/

/* für Elise
int melody[] = {NOTE_E5, NOTE_DS5, NOTE_E5, NOTE_DS5, NOTE_E5, NOTE_B4, NOTE_D5, NOTE_C5, NOTE_A4, 0, 
               NOTE_C4, NOTE_E4, NOTE_A4, NOTE_B4, 0, NOTE_E4,
               NOTE_GS4, NOTE_B4, NOTE_C5, 0, NOTE_E4,
               NOTE_E5, NOTE_DS5, NOTE_E5, NOTE_DS5, NOTE_E5, NOTE_B4, NOTE_D5, NOTE_C5, NOTE_A4, 0, 
               NOTE_C4, NOTE_E4, NOTE_A4, NOTE_B4, 0, NOTE_E4,
               NOTE_C5, NOTE_B4, NOTE_A4,0,};
uint8_t noteType[] = {8,8,8,8,8,8,8,8,4,8,8,8,8,4,8,8, 8,8,4,8,8, 8,8,8,8,8,8,8,8,4,8,8,8,8,4,8,8, 8,8,1,4};
bpm = 80;
*/

/* Ode to Joy - Beethoven's Symphony No. 9
int melody[] = {NOTE_E4,  NOTE_E4, NOTE_F4, NOTE_G4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4,
                NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_D4, NOTE_D4, NOTE_E4, 
                NOTE_E4, NOTE_F4, NOTE_G4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4, NOTE_C4, 
                NOTE_C4, NOTE_D4, NOTE_E4, NOTE_D4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_D4, 
                NOTE_E4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_F4, NOTE_E4, NOTE_C4, NOTE_D4, 
                NOTE_E4, NOTE_F4, NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_G3, NOTE_E4, 
                NOTE_E4, NOTE_F4, NOTE_G4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4, NOTE_C4, 
                NOTE_C4, NOTE_D4, NOTE_E4, NOTE_D4, NOTE_C4, NOTE_C4};
uint8_t noteType[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 2, 
                           4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 2,
                           4, 4, 4, 4, 4, 8, 8, 4, 4, 4, 8, 8, 4, 4, 4, 
                           4, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  
                           8, 2};
bpm = 114;
*/

/* Sweet Child O' Mine - Intro
int melody[] = {NOTE_CS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5, NOTE_CS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, 
                NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5, NOTE_DS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5, 
                NOTE_DS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5, NOTE_FS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, 
                NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5, NOTE_FS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5, 
                NOTE_CS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5, NOTE_CS5, NOTE_CS6, NOTE_GS5, NOTE_FS5, 
                NOTE_FS6, NOTE_GS5, NOTE_F6, NOTE_GS5};
uint8_t noteType[] = {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 
                           10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 
                           10, 10, 10, 10, 10, 10, 10, 10};
*/
/* Stairway to heaven
int melody[] = {NOTE_A4, NOTE_C5, NOTE_E5, NOTE_A5, NOTE_B5, NOTE_E5, NOTE_C5, NOTE_B5, NOTE_C6, NOTE_E5, NOTE_C5, NOTE_C6, NOTE_FS5, NOTE_D5, 
                NOTE_A4, NOTE_FS5, NOTE_E5, NOTE_C5, NOTE_A4, NOTE_C5, 0, NOTE_E5, NOTE_C5, NOTE_A4, NOTE_G4, NOTE_A4, NOTE_A4, 0, 0, NOTE_A4, 
                NOTE_F5, NOTE_E5, NOTE_A4, NOTE_A4, NOTE_C5, NOTE_E5, NOTE_B5, NOTE_E5, NOTE_C5, NOTE_B5, NOTE_C6, NOTE_E5, NOTE_C5, NOTE_C6, 
                NOTE_FS5, NOTE_D5, NOTE_A4, NOTE_FS5, NOTE_E5, NOTE_C5, NOTE_A4, NOTE_C5, 0, NOTE_E5, NOTE_C5, NOTE_A4, NOTE_G4, NOTE_A4, 
                NOTE_A4, 0, 0, 0, NOTE_A4, NOTE_B4, NOTE_C5, NOTE_E5, NOTE_G5, NOTE_C5, NOTE_B4, NOTE_D5, NOTE_G5, NOTE_B4, NOTE_B4, NOTE_C5, 
                NOTE_A4, NOTE_A4, NOTE_C5, NOTE_E5, NOTE_A5, NOTE_A4, NOTE_B4, NOTE_C5, NOTE_G4, NOTE_C4, NOTE_C5, NOTE_G5, NOTE_D5, NOTE_G4, 
                NOTE_G5, NOTE_G5, NOTE_FS5, NOTE_D5, NOTE_D5, 0, 0, NOTE_A4, NOTE_B4, NOTE_C5, NOTE_E5, NOTE_G5, NOTE_C5, NOTE_B4, NOTE_D5, 
                NOTE_G5, NOTE_B4, NOTE_B4, NOTE_C5, NOTE_A4, NOTE_A4, NOTE_C5, NOTE_E5, NOTE_A5, NOTE_A4, NOTE_B4, NOTE_C5, NOTE_E5, NOTE_G5, 
                NOTE_C6, NOTE_D5, NOTE_FS5, NOTE_A5, NOTE_D6, NOTE_E5, NOTE_E5, NOTE_E5, 0, 0};
uint8_t noteType[] = {8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 4, 12, 8, 8, 8, 8, 8, 8, 8, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 
                           8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 4, 12, 8, 8, 8, 8, 8, 8, 8, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 16, 16, 8, 
                           8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 16, 16, 8, 4, 12, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 16, 16, 8, 8, 8, 8, 8, 
                           8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 16, 8, 8, 8, 8, 2, 4, 4};
*/

/* A-ha! Take on Me 
 int melody[] = {NOTE_FS5, NOTE_FS5,NOTE_D5, NOTE_B4, 0, NOTE_B4, 0, NOTE_E5, 0, NOTE_E5, 
                 0, NOTE_E5, NOTE_GS5, NOTE_GS5, NOTE_A5, NOTE_B5, NOTE_A5, NOTE_A5, 
                 NOTE_A5, NOTE_E5, 0, NOTE_D5, 0, NOTE_FS5, 0, NOTE_FS5, 0, NOTE_FS5, 
                 NOTE_E5, NOTE_E5, NOTE_FS5, NOTE_E5, NOTE_FS5, NOTE_FS5,NOTE_D5, NOTE_B4, 
                 0, NOTE_B4, 0, NOTE_E5}; 
 int noteType[] = { 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 
                         8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8}; 
 bpm = 140;
*/

/* Never Gonna Give You Up - Rick Astley 
 int melody[] = {NOTE_D5, NOTE_E5, NOTE_A4, NOTE_E5, NOTE_FS5, NOTE_A5, NOTE_G5, NOTE_FS5, 
                 NOTE_D5, NOTE_E5, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_B4, NOTE_D5, NOTE_D5,
                 NOTE_D5, NOTE_E5, NOTE_A4, NOTE_E5, NOTE_FS5, NOTE_A5, NOTE_G5, NOTE_FS5,
                 NOTE_D5, NOTE_E5, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_B4, NOTE_D5, NOTE_D5,
                 0, NOTE_B4,NOTE_CS5, NOTE_D5, NOTE_D5, NOTE_E5, NOTE_CS5, NOTE_B4, 
                 NOTE_A4, 0 }; 
 int noteType[] = {4, 4, 4, 4, 4, 16, 16, 8, 4, 4, 2, 16, 16, 16, 8, 16, 4, 4, 4, 4, 
                        4, 16, 16, 8, 4, 4, 2, 16, 16, 16, 8, 16, 4, 8, 8, 8, 8, 8, 8, 16, 
                        2, 4 }; 
 bpm = 114;
*/

/* Correct Song
int melody[] = {NOTE_D5, NOTE_F5, NOTE_A5, NOTE_C6, NOTE_D6};
uint8_t noteType[] = {4,4,4,4,4};
*/

/* SariaSong
int melody[] = {NOTE_F4, NOTE_A4, NOTE_B4, NOTE_F4, NOTE_A4, NOTE_B4, NOTE_F4, NOTE_A4, NOTE_B4, NOTE_E5, NOTE_D5, NOTE_B4, NOTE_C5, 
                NOTE_B4, NOTE_G4, NOTE_E4, NOTE_D4, NOTE_E4, NOTE_G4}; 
uint8_t noteType[] = {8, 8, 4, 8, 8, 4, 8, 8, 8, 8, 4, 8, 8, 8, 8, 5, 8, 8, 8}; 
*/

/* Zelda Lullaby
int melody[] = {NOTE_E4,NOTE_G4, NOTE_D4,NOTE_C4,NOTE_D4, NOTE_E4, NOTE_G4, NOTE_D4, 
                NOTE_E4, NOTE_G4, NOTE_D5, NOTE_C5, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4, 
                NOTE_E4, NOTE_G4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_G4, NOTE_D4, 
                NOTE_E4, NOTE_G4}; 
uint8_t noteType[] =  {2, 4, 2, 8, 8, 2, 4, 2, 2, 4, 2, 4,
                            2, 8, 8, 2, 2, 4, 2, 8, 8, 2, 4, 2, 2, 4}; 
bpm = 108;
*/

/* Sun Song
int melody[] = {NOTE_A4, NOTE_F4, NOTE_D5, NOTE_A4, NOTE_F4, NOTE_D5, NOTE_A4, NOTE_B4, NOTE_C5, NOTE_D5, NOTE_E5, NOTE_F5}; 
uint8_t noteType[] =  {8, 8, 3, 8, 16, 4, 16, 16, 16, 16, 16, 16}; 
*/

/* Song of Storm
int melody[] = {NOTE_D4, NOTE_F4, NOTE_D5, NOTE_D4, NOTE_F4, NOTE_D5, NOTE_E5, NOTE_F5, NOTE_E5, NOTE_F5, NOTE_E5, NOTE_C5, NOTE_A4, NOTE_A4, 
                NOTE_D4, NOTE_F4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_D4, NOTE_F4, NOTE_G4}; 
uint8_t noteType[] = {8, 16, 4, 8, 16, 4, 4, 16, 16, 16, 16, 16, 4, 8, 8, 16, 16, 4, 8, 6, 16, 8}; 
bpm = 108;
*/

/* Epona Song
int melody[] = {NOTE_D5, NOTE_B4, NOTE_A4, NOTE_D5, NOTE_B4, NOTE_A4, NOTE_D5, NOTE_B4, NOTE_A4, NOTE_B4}; 
uint8_t noteType[] = {8, 8, 2, 8, 8, 2, 8, 8, 5, 5}; 
*/

/* Nokia ringtone
int melody[] = {NOTE_E5,NOTE_D5, NOTE_FS4, NOTE_GS4, NOTE_CS5, NOTE_B4, NOTE_D4, NOTE_E4, 
                NOTE_B4, NOTE_A4, NOTE_CS4, NOTE_E4, NOTE_A4};
uint8_t noteType[] = {8, 8, 4, 4, 8, 8, 4, 4, 8, 8, 4, 4, 2};
bpm = 180;
*/

/* Test melody 1
int melody[] = {NOTE_C5, NOTE_B4, NOTE_G4, NOTE_C5, NOTE_B4, NOTE_E4, 0, NOTE_C5, NOTE_C4, 
                NOTE_G4, NOTE_A4, NOTE_C5};
uint8_t noteType[] = {16,16,16,8,8,16,32,16,16,16,8,8};
*/

/* Test melody 2
 int melody[] = {NOTE_C4, NOTE_G3, NOTE_G3, NOTE_A3, NOTE_G3, 0, NOTE_B3, NOTE_C4}; 
 int noteType[] = {8, 16, 16, 8, 8, 8, 8, 8}; 
*/

  enableBuzzer();
  for(int i = 0; i < sizeof(melody)/sizeof(int); i++) {
     playOneNote(melody[i],noteType[i], bpm);
  }      
}